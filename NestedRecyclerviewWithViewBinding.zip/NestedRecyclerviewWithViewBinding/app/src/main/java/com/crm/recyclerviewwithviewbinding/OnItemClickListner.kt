package com.crm.recyclerviewwithviewbinding

interface OnItemClickListener {

    fun onItemClick(position: Int)
}