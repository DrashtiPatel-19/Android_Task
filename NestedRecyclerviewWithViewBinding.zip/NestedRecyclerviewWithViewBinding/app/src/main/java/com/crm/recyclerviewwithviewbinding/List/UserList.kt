package com.crm.recyclerviewwithviewbinding.List

import com.crm.recyclerviewwithviewbinding.R
import com.example.viewbindingwithrecyclerview.Modal.User

object UserList
{
    var userList = mutableListOf<User>(
        User(0 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(1 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList1),
        User(2 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(3 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList1),
        User(4 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(5 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList1),
        User(6 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(7 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList1),
        User(8 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(9 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList1),
        User(10 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(11 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList1),
        User(12 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(13 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList1),
        User(14 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(15 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList1),
        User(16 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(17 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList1),
        User(18 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList),
        User(19 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList),
        User(20 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList1),
        User(21 , R.drawable.shake1 , "Shake" , false,false,UserList2.child_userList),
        User(22 , R.drawable.pizza , "Pizza" , false,false,UserList2.child_userList1)



    )
}