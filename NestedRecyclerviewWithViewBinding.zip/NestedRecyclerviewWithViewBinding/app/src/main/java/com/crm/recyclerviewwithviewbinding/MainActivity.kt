package com.crm.recyclerviewwithviewbinding

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.crm.recyclerviewwithviewbinding.List.UserList
import com.crm.recyclerviewwithviewbinding.List.UserList2
import com.crm.recyclerviewwithviewbinding.databinding.ActivityMainBinding
import com.example.viewbindingwithrecyclerview.Adapter.MyAdapter
import com.example.viewbindingwithrecyclerview.Modal.User

class MainActivity : AppCompatActivity() {
    private var binding : ActivityMainBinding ?= null
    private var userList : MutableList<User> = mutableListOf()
    private var adapter : MyAdapter = MyAdapter(UserList.userList)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        //adapter = MyAdapter(UserList.userList)
        binding?.revData?.adapter = adapter

        binding?.btnAdd?.setOnClickListener {
            UserList.userList.add(User(23 , R.drawable.pizza,"ABC",false,false,UserList2.child_userList))
            UserList.userList.add(User(24 , R.drawable.ic_launcher_background,"ABCD",false,false,UserList2.child_userList1))
            //Log.d("mydata", userList.toString())
            adapter.notifyItemInserted(UserList.userList.size-1)
            binding?.revData?.scrollToPosition(UserList.userList.size-1)
        }


        adapter.onItemClickListner(object : OnItemClickListener{
            override fun onItemClick(position: Int) {

            }
        })

    }
}