package com.crm.recyclerviewwithviewbinding.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.crm.recyclerviewwithviewbinding.Modal.Child_User
import com.crm.recyclerviewwithviewbinding.databinding.ChildRawLayoutBinding

class ChildAdapter(private val childList : List<Child_User> , private val parentPosition: Int , private val childCheck : Boolean) : RecyclerView.Adapter<ChildAdapter.ViewHolder>()
{
    var selectPosition = -1

    class ViewHolder(val itembind: ChildRawLayoutBinding) : RecyclerView.ViewHolder(itembind.root)
    {
        fun bindItems(childUser : Child_User)
        {
            itembind.childImgview.setImageResource(childUser.img)
            itembind.childTitle.text = childUser.title
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = ChildRawLayoutBinding.inflate(LayoutInflater.from(parent.context) , parent , false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val users = childList[position]
        var childAdapter = ChildAdapter(childList , parentPosition,false)
        holder.bindItems(users)
        holder.itembind.childBtn.text = "btn _ $parentPosition _ $position"

        if(childCheck){
            holder.itembind.checkbox1.isChecked = true
            childAdapter.notifyDataSetChanged()
        }
        else
        {
            holder.itembind.checkbox1.isChecked = false
        }
        holder.itembind.checkbox1.setOnClickListener {
            Toast.makeText(holder.itemView.context, "Clicked", Toast.LENGTH_SHORT).show()
            selectPosition = position
            if(!users.isChildCheckBox)
            {
                users.isChildCheckBox = true
                holder.itembind.checkbox1.isChecked = users.isChildCheckBox
                //childAdapter.notifyDataSetChanged()
            }
            else
            {
                users.isChildCheckBox = false
            }
            childAdapter.notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return childList.size
    }
}