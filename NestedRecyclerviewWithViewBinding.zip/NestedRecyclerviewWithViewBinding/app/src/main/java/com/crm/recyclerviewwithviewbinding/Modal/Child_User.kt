package com.crm.recyclerviewwithviewbinding.Modal

data class Child_User(val img : Int , var title : String , var isChildCheckBox : Boolean = false)

