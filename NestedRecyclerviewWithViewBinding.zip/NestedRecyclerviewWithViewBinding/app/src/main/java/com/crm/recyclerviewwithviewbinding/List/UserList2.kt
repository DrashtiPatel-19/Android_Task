package com.crm.recyclerviewwithviewbinding.List

import com.crm.recyclerviewwithviewbinding.Modal.Child_User
import com.crm.recyclerviewwithviewbinding.R

object UserList2
{
    var child_userList = mutableListOf<Child_User>(
        Child_User(R.drawable.pizza , "Pasta" , false),
        Child_User(R.drawable.shake1 , "Fries" , false),

    )

    var child_userList1 = mutableListOf<Child_User>(
        Child_User(R.drawable.pizza , "Fires" , false),
    )
}