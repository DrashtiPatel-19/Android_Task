package com.example.viewbindingwithrecyclerview.Adapter

import android.annotation.SuppressLint
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.crm.recyclerviewwithviewbinding.Adapter.ChildAdapter
import com.crm.recyclerviewwithviewbinding.List.UserList
import com.crm.recyclerviewwithviewbinding.OnItemClickListener
import com.crm.recyclerviewwithviewbinding.databinding.RawLayoutBinding
import com.example.viewbindingwithrecyclerview.Modal.User


class MyAdapter(private val userList: List<User>) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {
    var selectPos = -1
    var childCheck = false

    private var mListener: OnItemClickListener? = null

    fun onItemClickListner(listner: OnItemClickListener) {
        mListener = listner
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            RawLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(view)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = userList[position]
        holder.bindItems(user)
        val parentId = userList[position].id
        val adapter = MyAdapter(UserList.userList)
        val childAdapter =
            ChildAdapter(UserList.userList[position].new_list, parentId!!, childCheck)
        holder.binding.todoRVChild.adapter = childAdapter
        holder.binding.checkbox.isChecked = selectPos == position
        holder.binding.checkbox.isChecked = user.isSelected

          // code used for stop

        if (user.isExpand) {
            holder.binding.todoRVChild.visibility = View.VISIBLE
        } else {
            holder.binding.todoRVChild.visibility = View.GONE
        }

        // for checkbox
        holder.binding.checkbox.isChecked = selectPos == position
        holder.binding.checkbox.isChecked = user.isChekedcheckbox
        holder.binding.checkbox.setOnClickListener {

            Toast.makeText(holder.itemView.context, "Clicked", Toast.LENGTH_SHORT).show()
            //childCheck = false
            selectPos = position

            if (!user.isChekedcheckbox) {
                user.isChekedcheckbox = true
                //Log.d("mydata" , position.toString())
                //holder.binding.checkbox.isChecked = user.isSelected
                childCheck = true
                notifyDataSetChanged()
                //holder.binding.checkbox.isChecked = true
                //adapter.notifyDataSetChanged()
            } else {
                user.isChekedcheckbox = false
                childCheck = false
                notifyDataSetChanged()
            }
            adapter.notifyDataSetChanged()
        }

        if (selectPos == position) {
            //UserList.userList[position].setIsClicked(false)
            holder.binding.todoRVChild.visibility = View.VISIBLE
        } else {
            holder.binding.todoRVChild.visibility = View.GONE
        }
        holder.itemView.setOnClickListener {
            selectPos = position
            if (UserList.userList[position].getIsClicked()) {
                UserList.userList[position].setIsClicked(false)
                notifyDataSetChanged()
            } else {
                if (holder.binding.todoRVChild.visibility == View.VISIBLE && selectPos == position) {
                    holder.binding.todoRVChild.visibility = View.GONE
                    //childCheck = true
                    UserList.userList[position].setIsClicked(false)
                } else {
                    UserList.userList[position].setIsClicked(true)
                    childCheck = false
                    UserList.userList[position].setIsClicked(false)
                    notifyDataSetChanged()
                }
            }
//            if (!user.getIsClicked()) {
//                //Log.d("mydata" , selectPos.toString())
//                mListener?.onItemClick(position)
//                holder.binding.todoRVChild.visibility = View.VISIBLE
//                user.setIsClicked(true)
//                childCheck = true
//
//            } else {
//                holder.binding.todoRVChild.visibility = View.GONE
//                user.setIsClicked(false)
//                childCheck = false
//            }


        }
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    class ViewHolder(val binding: RawLayoutBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bindItems(user: User) {
            binding.imgview.setImageResource(user.image)
            binding.tvUsername.text = user.title
        }
    }

}