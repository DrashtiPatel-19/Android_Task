package com.example.viewbindingwithrecyclerview.Modal

import com.crm.recyclerviewwithviewbinding.List.UserList2
import com.crm.recyclerviewwithviewbinding.Modal.Child_User

data class User(
    var id:Int ?= null, var image: Int, var title: String, var isClicked: Boolean = false, var isChekedcheckbox: Boolean = false,
    var new_list: MutableList<Child_User>)
{
    var isSelected : Boolean = false
    var isExpand : Boolean = false

    fun getId():Int{
        return id!!
    }

    fun setId(id:Int){
        this.id = id
    }

    fun getIsClicked(): Boolean {
        return isClicked
    }

    fun setIsClicked(isClicked: Boolean) {
        this.isClicked = isClicked
    }
}
